#ifndef TWEAK_H
#define TWEAK_H

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "logger.h"
#import "MJPEGReader.h"
#import "MJPEGPreviewWindow.h"
#import "VirtualCameraController.h"
#import "GetFrame.h"
#import <objc/runtime.h>
#import "Globals.h"

// Incluir todos os outros arquivos de cabeçalho necessários

#endif /* TWEAK_H */
